# Slug_on_shrew > 2023-09-24 1:52pm
https://universe.roboflow.com/computer-vision-lab-yzv09/slug_on_shrew

Provided by a Roboflow user
License: CC BY 4.0

